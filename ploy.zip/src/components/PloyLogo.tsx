import React from "react";

interface PloyLogoProps {
  className?: string;
  height?: number | string;
  width?: number | string;
}

export default function PloyLogo({ className = "", height = "40", width = "120" }: PloyLogoProps) {
  const bgGreen = "#5ce69a";
  const borderGreen = "#235035";

  return (
    <svg
      viewBox="0 0 400 130"
      width={width}
      height={height}
      className={`select-none ${className}`}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Outer Rounded Capsule Background */}
      <rect
        x="6"
        y="6"
        width="388"
        height="118"
        rx="38"
        fill={bgGreen}
        stroke={borderGreen}
        strokeWidth="6"
      />

      {/* Group of layered strokes for the double-line effect */}
      {/* Layer 1: Thick Black base */}
      <g
        fill="none"
        stroke="#000000"
        strokeWidth="14"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M 65,35 L 65,95 M 65,35 H 85 C 100,35 100,65 85,65 H 65" /> {/* P */}
        <path d="M 130,35 L 130,95 H 175" /> {/* L */}
        <circle cx="235" cy="65" r="26" /> {/* O */}
        <path d="M 295,35 L 320,65 L 320,95 M 345,35 L 320,65" /> {/* Y */}
        <circle cx="370" cy="90" r="4" /> {/* . */}
      </g>

      {/* Layer 2: Green gap */}
      <g
        fill="none"
        stroke={bgGreen}
        strokeWidth="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M 65,35 L 65,95 M 65,35 H 85 C 100,35 100,65 85,65 H 65" /> {/* P */}
        <path d="M 130,35 L 130,95 H 175" /> {/* L */}
        <circle cx="235" cy="65" r="26" /> {/* O */}
        <path d="M 295,35 L 320,65 L 320,95 M 345,35 L 320,65" /> {/* Y */}
        <circle cx="370" cy="90" r="4" /> {/* . */}
      </g>

      {/* Layer 3: Inner Black line */}
      <g
        fill="none"
        stroke="#000000"
        strokeWidth="6"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M 65,35 L 65,95 M 65,35 H 85 C 100,35 100,65 85,65 H 65" /> {/* P */}
        <path d="M 130,35 L 130,95 H 175" /> {/* L */}
        <circle cx="235" cy="65" r="26" /> {/* O */}
        <path d="M 295,35 L 320,65 L 320,95 M 345,35 L 320,65" /> {/* Y */}
        <circle cx="370" cy="90" r="4" /> {/* . */}
      </g>

      {/* Layer 4: Green center core */}
      <g
        fill="none"
        stroke={bgGreen}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M 65,35 L 65,95 M 65,35 H 85 C 100,35 100,65 85,65 H 65" /> {/* P */}
        <path d="M 130,35 L 130,95 H 175" /> {/* L */}
        <circle cx="235" cy="65" r="26" /> {/* O */}
        <path d="M 295,35 L 320,65 L 320,95 M 345,35 L 320,65" /> {/* Y */}
        <circle cx="370" cy="90" r="4" /> {/* . */}
      </g>
    </svg>
  );
}
