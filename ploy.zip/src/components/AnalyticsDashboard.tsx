import React, { useState, useMemo } from "react";
import { MarketInsights, HeatmapNode, CacLtvPredictorNode } from "../types";
import { MapPin, Sliders, TrendingUp, Sparkles, MessageSquare, AlertCircle, RefreshCw, BarChart2, DollarSign, Languages } from "lucide-react";

interface AnalyticsDashboardProps {
  insights: MarketInsights;
  stateName: string;
}

export default function AnalyticsDashboard({ insights, stateName }: AnalyticsDashboardProps) {
  // Sorting state for the heatmaps
  const [heatmapSortBy, setHeatmapSortBy] = useState<"demand" | "competition" | "purchasing">("demand");
  const [selectedNode, setSelectedNode] = useState<HeatmapNode | null>(insights.regionalHeatmaps[0] || null);
  
  // Interactive Simulator States
  const [simulateBudget, setSimulateBudget] = useState<number>(25000); // Monthly budget in INR
  const [selectedChannelIndex, setSelectedChannelIndex] = useState<number>(0);

  // Sorting the heatmap nodes
  const sortedHeatmaps = useMemo(() => {
    return [...insights.regionalHeatmaps].sort((a, b) => {
      if (heatmapSortBy === "demand") return b.demandIntensity - a.demandIntensity;
      if (heatmapSortBy === "competition") return b.competitorDensity - a.competitorDensity;
      return b.purchasingPowerIndex - a.purchasingPowerIndex;
    });
  }, [insights.regionalHeatmaps, heatmapSortBy]);

  // Calculations for CAC/LTV Simulator
  const activeChannel = insights.cacLtvPredictor[selectedChannelIndex] || insights.cacLtvPredictor[0];
  
  const simulationResults = useMemo(() => {
    if (!activeChannel) return { minAcquired: 0, maxAcquired: 0, avgCAC: 0, ltvReturnMin: 0, ltvReturnMax: 0 };
    
    const minAcquired = Math.round(simulateBudget / activeChannel.cacMax);
    const maxAcquired = Math.round(simulateBudget / activeChannel.cacMin);
    const avgCAC = Math.round((activeChannel.cacMin + activeChannel.cacMax) / 2);
    
    const ltvReturnMin = minAcquired * activeChannel.ltvMin;
    const ltvReturnMax = maxAcquired * activeChannel.ltvMax;

    return { minAcquired, maxAcquired, avgCAC, ltvReturnMin, ltvReturnMax };
  }, [activeChannel, simulateBudget]);

  const getDemandColor = (val: number) => {
    if (val >= 80) return "bg-rose-500";
    if (val >= 60) return "bg-orange-400";
    return "bg-amber-400";
  };

  const getIntensityBadge = (val: number) => {
    if (val >= 80) return { text: "High Demand", bg: "bg-rose-50 text-rose-700 border-rose-100" };
    if (val >= 60) return { text: "Moderate", bg: "bg-orange-50 text-orange-700 border-orange-100" };
    return { text: "Steady", bg: "bg-amber-50 text-amber-700 border-amber-100" };
  };

  return (
    <div className="space-y-8">
      {/* SECTION 1: REGIONAL DEMAND HEATMAPS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Heatmap Node Grid & State Selector */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-emerald-600" />
                Regional Market Heatmap: {stateName}
              </h3>
              <p className="text-xs text-slate-500">
                Granular district analysis of spending power and category density.
              </p>
            </div>

            {/* Sorting controls */}
            <div className="flex bg-slate-100 p-1 rounded-xl self-start sm:self-auto">
              <button
                onClick={() => setHeatmapSortBy("demand")}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  heatmapSortBy === "demand" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500"
                }`}
              >
                Demand
              </button>
              <button
                onClick={() => setHeatmapSortBy("competition")}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  heatmapSortBy === "competition" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500"
                }`}
              >
                Competition
              </button>
              <button
                onClick={() => setHeatmapSortBy("purchasing")}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  heatmapSortBy === "purchasing" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500"
                }`}
              >
                Wealth
              </button>
            </div>
          </div>

          {/* List of nodes */}
          <div className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
            <div className="divide-y divide-slate-50">
              {sortedHeatmaps.map((node) => {
                const isSelected = selectedNode?.name === node.name;
                const badge = getIntensityBadge(node.demandIntensity);
                return (
                  <div
                    key={node.name}
                    onClick={() => setSelectedNode(node)}
                    className={`p-4 flex items-center justify-between gap-4 cursor-pointer transition-colors ${
                      isSelected ? "bg-emerald-50/40 border-l-4 border-emerald-500 pl-3" : "hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-800 truncate">{node.name}</span>
                        <span className="text-xs font-mono text-slate-400">PIN {node.pinCode}</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 mt-2 max-w-xs sm:max-w-md">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Demand</span>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <div className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                            <span className="text-xs font-bold text-slate-700">{node.demandIntensity}%</span>
                          </div>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Competition</span>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                            <span className="text-xs font-bold text-slate-700">{node.competitorDensity}%</span>
                          </div>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Purchasing Power</span>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                            <span className="text-xs font-bold text-slate-700">{node.purchasingPowerIndex}%</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1.5">
                      <span className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded border ${badge.bg}`}>
                        {badge.text}
                      </span>
                      <span className="text-[10px] text-slate-400">Click to focus</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Selected Hub Deep-dive Card */}
        <div className="lg:col-span-5 flex flex-col justify-between">
          {selectedNode ? (
            <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md flex flex-col justify-between h-full relative overflow-hidden">
              {/* Background Glow */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

              <div>
                <span className="text-[10px] font-mono tracking-widest text-emerald-400 uppercase font-bold block mb-1">
                  Active Hub Analysis
                </span>
                <h4 className="text-2xl font-bold text-white tracking-tight">{selectedNode.name}</h4>
                <div className="inline-flex items-center gap-1.5 mt-2 px-2 py-1 rounded bg-slate-800 text-slate-300 font-mono text-xs">
                  <MapPin className="w-3 h-3 text-emerald-400" />
                  Primary Postal Hub: {selectedNode.pinCode}
                </div>

                <div className="space-y-4 mt-6">
                  {/* Demand Intensity Progress */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                      <span>Demand Intensity Index</span>
                      <span className="text-white font-bold">{selectedNode.demandIntensity}/100</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5">
                      <div
                        className="bg-rose-500 h-1.5 rounded-full"
                        style={{ width: `${selectedNode.demandIntensity}%` }}
                      />
                    </div>
                  </div>

                  {/* Competitor Density */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                      <span>Competitor Density Index</span>
                      <span className="text-white font-bold">{selectedNode.competitorDensity}/100</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5">
                      <div
                        className="bg-indigo-400 h-1.5 rounded-full"
                        style={{ width: `${selectedNode.competitorDensity}%` }}
                      />
                    </div>
                  </div>

                  {/* Wealth index */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                      <span>Regional Purchasing Power</span>
                      <span className="text-white font-bold">{selectedNode.purchasingPowerIndex}/100</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5">
                      <div
                        className="bg-emerald-400 h-1.5 rounded-full"
                        style={{ width: `${selectedNode.purchasingPowerIndex}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Strategy Suggestion */}
              <div className="mt-8 pt-4 border-t border-slate-800">
                <div className="flex items-start gap-3">
                  <Sparkles className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-emerald-400 block uppercase tracking-wider">
                      Localized Verdict
                    </span>
                    <p className="text-xs text-slate-300 leading-relaxed mt-1">
                      {selectedNode.demandIntensity >= 80 && selectedNode.competitorDensity <= 50 ? (
                        <span>🔥 **High-Opportunity Golden Pocket**: Demand is extremely strong, but competitor coverage is relatively sparse. Direct heavy offline distribution and local WhatsApp blasts here first!</span>
                      ) : selectedNode.demandIntensity >= 75 && selectedNode.competitorDensity >= 70 ? (
                        <span>⚡ **Competitive Battleground**: Strong consumer appetite, but highly saturated. Focus heavily on pricing differentiation or custom regional bundles rather than expensive ads.</span>
                      ) : (
                        <span>🌾 **Steady Growth Hub**: Ideal testbed for product validation. Establish low-cost mom-and-pop store (Kirana) sample counters to gauge organic feedback.</span>
                      )}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl p-8 flex flex-col items-center justify-center text-center h-full">
              <AlertCircle className="w-8 h-8 text-slate-300 mb-2" />
              <p className="text-sm text-slate-500">Select a regional hub from the list to analyze opportunity patterns.</p>
            </div>
          )}
        </div>
      </div>

      {/* SECTION 2: REGIONAL CAC & LTV PREDICTOR WITH INTERACTIVE BUDGET SIMULATOR */}
      <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-xs space-y-6">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-indigo-600" />
            <h3 className="text-lg font-bold text-slate-800">Regional CAC & LTV Predictor</h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Aggregated localized channels forecasts. Drag the simulator slider to forecast budget efficiency.
          </p>
        </div>

        {/* Channel Selector */}
        <div className="flex flex-wrap gap-2.5">
          {insights.cacLtvPredictor.map((channel, idx) => (
            <button
              key={channel.channel}
              onClick={() => setSelectedChannelIndex(idx)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                selectedChannelIndex === idx
                  ? "bg-indigo-600 text-white border-indigo-600 shadow-xs"
                  : "bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200/60"
              }`}
            >
              {channel.channel} (Est. Efficiency: {channel.efficiency}%)
            </button>
          ))}
        </div>

        {/* Interactive Slider & Simulation Outputs */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pt-2">
          {/* Slider Controls */}
          <div className="md:col-span-5 bg-slate-50 p-5 rounded-2xl border border-slate-100/60 space-y-5">
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Simulate Monthly Budget</span>
                <span className="text-sm font-bold text-indigo-700">₹{simulateBudget.toLocaleString("en-IN")}</span>
              </div>
              <input
                type="range"
                min="5000"
                max="300000"
                step="5000"
                value={simulateBudget}
                onChange={(e) => setSimulateBudget(Number(e.target.value))}
                className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>₹5K</span>
                <span>₹1 Lakh</span>
                <span>₹2 Lakhs</span>
                <span>₹3 Lakhs</span>
              </div>
            </div>

            <div className="text-xs text-slate-600 space-y-2 border-t border-slate-200/40 pt-4">
              <div className="flex justify-between">
                <span>Predicted CAC Range:</span>
                <span className="font-semibold text-slate-700">₹{activeChannel.cacMin} - ₹{activeChannel.cacMax}</span>
              </div>
              <div className="flex justify-between">
                <span>Expected customer LTV:</span>
                <span className="font-semibold text-slate-700 text-emerald-600">₹{activeChannel.ltvMin} - ₹{activeChannel.ltvMax}</span>
              </div>
              <div className="flex justify-between">
                <span>Typical LTV:CAC Ratio:</span>
                <span className="font-bold text-slate-700 text-indigo-600">
                  {Math.round(activeChannel.ltvMin / activeChannel.cacMax)}x to {Math.round(activeChannel.ltvMax / activeChannel.cacMin)}x
                </span>
              </div>
            </div>
          </div>

          {/* Simulation outputs */}
          <div className="md:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Acquired Box */}
            <div className="bg-indigo-50/50 border border-indigo-100/40 rounded-2xl p-5 flex flex-col justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider">Estimated New Customers</span>
                <h4 className="text-3xl font-black text-indigo-950 mt-1">
                  {simulationResults.minAcquired} – {simulationResults.maxAcquired}
                </h4>
                <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">
                  Based on a hyper-local blended CAC of <span className="font-bold">₹{simulationResults.avgCAC}</span>.
                </p>
              </div>
              <span className="text-[10px] text-indigo-500 mt-3 block">Calculated for lean operations</span>
            </div>

            {/* Total Estimated ROI */}
            <div className="bg-emerald-50/50 border border-emerald-100/40 rounded-2xl p-5 flex flex-col justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-emerald-700 tracking-wider">Estimated Lifetime Value Return</span>
                <h4 className="text-3xl font-black text-emerald-950 mt-1">
                  ₹{simulationResults.ltvReturnMin.toLocaleString("en-IN")} – ₹{simulationResults.ltvReturnMax.toLocaleString("en-IN")}
                </h4>
                <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">
                  Calculated using realistic regional retention trends.
                </p>
              </div>
              <span className="text-[10px] text-emerald-600 mt-3 block font-semibold">
                ROI Multiplier: ~{Math.round(simulationResults.ltvReturnMin / simulateBudget)}x
              </span>
            </div>

          </div>
        </div>
      </div>

      {/* SECTION 3: VERNACULAR & SENTIMENT ANALYTICS */}
      <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-xs">
        <div className="mb-6">
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Languages className="w-5 h-5 text-amber-500" />
            Vernacular & Sentiment Analytics
          </h3>
          <p className="text-xs text-slate-500">
            Regional social listening sentiment profiles and optimized regional marketing taglines.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Sentiment list */}
          <div className="space-y-4">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">Language Sentiment Scores</span>
            <div className="space-y-4">
              {insights.vernacularSentiment.map((s) => (
                <div key={s.language} className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-sm text-slate-800">{s.language}</span>
                    <span className="text-[11px] text-slate-500 block">Category Sentiment: <span className="font-semibold text-slate-700">{s.sentiment}</span></span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-xs font-mono text-slate-400 block">Affinities</span>
                      <span className="font-bold text-sm text-slate-800">{s.sentimentScore}%</span>
                    </div>
                    <div className="w-12 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className={`h-1.5 rounded-full ${
                          s.sentiment === "Positive" ? "bg-emerald-500" : s.sentiment === "Negative" ? "bg-red-400" : "bg-amber-400"
                        }`}
                        style={{ width: `${s.sentimentScore}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Slogans Panel */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100/80 flex flex-col justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-amber-600 tracking-wider block">
                ⭐ AI-Generated High-Converting Ad Taglines
              </span>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Optimized copy specifically engineered for vernacular WhatsApp campaigns or regional Facebook videos.
              </p>

              <div className="space-y-4 mt-4">
                {insights.vernacularSentiment.map((s, index) => (
                  <div key={index} className="border-l-4 border-amber-400 pl-3.5 space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{s.language}</span>
                    <blockquote className="text-sm font-bold text-slate-800 italic">
                      "{s.sampleSlogan}"
                    </blockquote>
                    <p className="text-xs text-slate-600">
                      <span className="font-semibold">English Translation:</span> {s.translation}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2 mt-6 pt-3 border-t border-slate-200/40 text-[10px] text-slate-400 leading-relaxed">
              <MessageSquare className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <span>Vernacular marketing achieves up to 3x higher CTR (Click-Through-Rate) in Indian Tier 2/3 markets compared to English equivalents.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
