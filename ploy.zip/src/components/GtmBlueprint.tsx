import React, { useState } from "react";
import { GtmBlueprintType, ChecklistItem } from "../types";
import { CheckSquare, Square, AlertCircle, FileText, Download, Clipboard, Check, Truck, Globe, MapPin, Share2 } from "lucide-react";

interface GtmBlueprintProps {
  blueprint: GtmBlueprintType;
}

export default function GtmBlueprint({ blueprint }: GtmBlueprintProps) {
  // Local checklist state to allow interactive checking/unchecking
  const [checklist, setChecklist] = useState<ChecklistItem[]>(() => {
    return blueprint.localizationChecklist.map((item) => ({
      ...item,
      completed: false
    }));
  });

  const [copied, setCopied] = useState(false);

  const completedCount = checklist.filter((item) => item.completed).length;
  const totalCount = checklist.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const toggleTask = (index: number) => {
    const updated = [...checklist];
    updated[index].completed = !updated[index].completed;
    setChecklist(updated);
  };

  const getPriorityStyle = (priority: string) => {
    switch (priority) {
      case "High":
        return "bg-rose-50 text-rose-700 border-rose-100";
      case "Medium":
        return "bg-amber-50 text-amber-700 border-amber-100";
      default:
        return "bg-slate-50 text-slate-600 border-slate-100";
    }
  };

  // Export as Text File
  const handleExportFile = () => {
    let textContent = `==================================================\n`;
    textContent += `PLOY GTM: AUTOMATED LOCALIZED GTM PLAYBOOK\n`;
    textContent += `Generated for Small Operations Teams & MSMEs\n`;
    textContent += `==================================================\n\n`;

    textContent += `PART 1: LOCALIZATION CHECKLIST\n`;
    textContent += `--------------------------------------------------\n`;
    checklist.forEach((item, idx) => {
      const status = item.completed ? "[X]" : "[ ]";
      textContent += `${idx + 1}. ${status} [${item.priority} Priority] ${item.task}\n`;
      textContent += `   Description: ${item.desc}\n\n`;
    });

    textContent += `PART 2: OPERATIONAL DISTRIBUTION ROADMAP\n`;
    textContent += `--------------------------------------------------\n`;
    textContent += `1. LOGISTICS GUIDELINES:\n${blueprint.distributionRoadmap.logisticsGuidelines}\n\n`;
    textContent += `2. INFRASTRUCTURE & LAST-MILE CHALLENGES:\n${blueprint.distributionRoadmap.infrastructureChallenges}\n\n`;
    textContent += `3. RECOMMENDED LOCAL DELIVERY PARTNERS:\n${blueprint.distributionRoadmap.deliveryPartners}\n\n`;
    textContent += `4. TARGET DIGITAL OUTREACH CHANNELS:\n${blueprint.distributionRoadmap.digitalOutreachChannels}\n\n`;

    textContent += `==================================================\n`;
    textContent += `Democratizing Market Scaling – PLOY GTM\n`;
    textContent += `==================================================`;

    const blob = new Blob([textContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "PLOY_Operations_Playbook.txt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Copy to Clipboard
  const handleCopyToClipboard = () => {
    let textContent = `PLOY GTM PLAYBOOK SUMMARY\n\n`;
    textContent += `Localization Tasks:\n`;
    checklist.forEach((item, idx) => {
      const status = item.completed ? "✓" : "☐";
      textContent += `- ${status} [${item.priority}] ${item.task}\n`;
    });
    textContent += `\nDelivery Partners: ${blueprint.distributionRoadmap.deliveryPartners}\n`;
    textContent += `Logistics Summary: ${blueprint.distributionRoadmap.logisticsGuidelines}`;

    navigator.clipboard.writeText(textContent).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="space-y-8">
      
      {/* SECTION 1: AUTOMATED STRATEGY ENGINE LOCALIZATION CHECKLIST */}
      <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <CheckSquare className="w-5 h-5 text-emerald-600" />
              Operational Localization Checklist
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Interactive checks necessary to adapt your logistics, billing, and customer service for the region.
            </p>
          </div>

          {/* Progress Indicator */}
          <div className="flex items-center gap-3 bg-slate-50 border border-slate-100 px-4 py-2 rounded-xl">
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block uppercase font-mono font-bold">GTM Readiness</span>
              <span className="text-sm font-bold text-slate-800">{completedCount} of {totalCount} Completed</span>
            </div>
            <div className="w-14 h-14 relative flex items-center justify-center">
              {/* Circular progress visual */}
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-100"
                  strokeWidth="3"
                  stroke="currentColor"
                  fill="transparent"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="text-emerald-500 transition-all duration-300"
                  strokeDasharray={`${progressPercent}, 100`}
                  strokeWidth="3"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="transparent"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <span className="absolute text-xs font-mono font-bold text-emerald-700">{progressPercent}%</span>
            </div>
          </div>
        </div>

        {/* Checklist List */}
        <div className="space-y-4">
          {checklist.map((item, idx) => (
            <div
              key={idx}
              onClick={() => toggleTask(idx)}
              className={`p-4 border rounded-2xl cursor-pointer transition-all flex items-start gap-4 ${
                item.completed
                  ? "bg-slate-50/50 border-slate-200/80 text-slate-400"
                  : "bg-white hover:bg-slate-50/20 border-slate-100 shadow-xs text-slate-800"
              }`}
            >
              {/* Check Icon */}
              <div className="flex-shrink-0 mt-0.5">
                {item.completed ? (
                  <Check className="w-5 h-5 text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-md p-0.5" />
                ) : (
                  <div className="w-5 h-5 border border-slate-300 rounded-md hover:border-emerald-500" />
                )}
              </div>

              {/* Task Title & Details */}
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`font-bold text-sm ${item.completed ? "line-through text-slate-400" : "text-slate-800"}`}>
                    {item.task}
                  </span>
                  <span className={`px-2 py-0.5 text-[9px] font-bold border rounded uppercase ${getPriorityStyle(item.priority)}`}>
                    {item.priority} Priority
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 2: OPERATIONAL DISTRIBUTION ROADMAPS */}
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Truck className="w-5 h-5 text-emerald-600" />
            Operational Distribution Roadmap
          </h3>
          <p className="text-xs text-slate-500">
            Physical delivery, shipping structures, and outreach vectors designed for Indian transport networks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Box 1: Logistics Guidelines */}
          <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs space-y-2 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl pointer-events-none" />
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
                <Truck className="w-4 h-4" />
              </span>
              <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider">Logistics Guidelines</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-medium pt-1">
              {blueprint.distributionRoadmap.logisticsGuidelines}
            </p>
          </div>

          {/* Box 2: Infrastructure Challenges */}
          <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs space-y-2 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/5 rounded-full blur-xl pointer-events-none" />
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-rose-50 text-rose-600 rounded-lg">
                <AlertCircle className="w-4 h-4" />
              </span>
              <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider">Local Infrastructure Risks</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-medium pt-1">
              {blueprint.distributionRoadmap.infrastructureChallenges}
            </p>
          </div>

          {/* Box 3: Delivery Partners */}
          <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs space-y-2 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-xl pointer-events-none" />
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                <MapPin className="w-4 h-4" />
              </span>
              <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider">Recommended Delivery Partners</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-medium pt-1">
              {blueprint.distributionRoadmap.deliveryPartners}
            </p>
          </div>

          {/* Box 4: Outreach channels */}
          <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs space-y-2 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-xl pointer-events-none" />
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
                <Globe className="w-4 h-4" />
              </span>
              <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider">Recommended Outreach Channels</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-medium pt-1">
              {blueprint.distributionRoadmap.digitalOutreachChannels}
            </p>
          </div>
        </div>
      </div>

      {/* SECTION 3: EXPORT UTILITIES */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-slate-800 text-emerald-400 rounded-xl">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Deploy GTM Blueprint to Team</h4>
            <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
              Export this playbook as a formatted TXT file or copy a summary directly to share on WhatsApp or Slack.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-shrink-0 w-full sm:w-auto">
          {/* Copy summary button */}
          <button
            onClick={handleCopyToClipboard}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-all"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                Copied!
              </>
            ) : (
              <>
                <Clipboard className="w-4 h-4" />
                Copy Summary
              </>
            )}
          </button>

          {/* Download button */}
          <button
            onClick={handleExportFile}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-bold rounded-xl transition-all shadow-sm"
          >
            <Download className="w-4 h-4" />
            Download Playbook
          </button>
        </div>
      </div>
    </div>
  );
}
