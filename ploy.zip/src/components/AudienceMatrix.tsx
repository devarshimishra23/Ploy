import React, { useState } from "react";
import { DemographicProfile, DemographicDetail } from "../types";
import { Users, CreditCard, Languages, Compass, Target, CheckCircle2 } from "lucide-react";

interface AudienceMatrixProps {
  profile: DemographicProfile;
}

export default function AudienceMatrix({ profile }: AudienceMatrixProps) {
  const [activeMobileTab, setActiveMobileTab] = useState<"tier1" | "tier2" | "tier3">("tier2");

  const renderTierCard = (tierKey: "tier1" | "tier2" | "tier3", title: string, subtitle: string, detail: DemographicDetail, accentColor: string, bgAccent: string) => {
    return (
      <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm hover:shadow-md transition-shadow duration-300 relative overflow-hidden flex flex-col justify-between h-full">
        {/* Decorative corner tag for volume */}
        <div className={`absolute top-0 right-0 ${bgAccent} ${accentColor} px-4 py-1.5 rounded-bl-xl font-mono text-xs font-bold flex items-center gap-1`}>
          <Target className="w-3.5 h-3.5" />
          {detail.volumePercent || (tierKey === "tier3" ? 50 : tierKey === "tier2" ? 35 : 15)}% Volume
        </div>

        <div>
          <div className="mb-4">
            <span className={`inline-block px-2.5 py-1 rounded-md text-xs font-semibold ${bgAccent} ${accentColor} mb-2`}>
              {title}
            </span>
            <h3 className="text-lg font-bold text-slate-800">{subtitle}</h3>
          </div>

          <div className="space-y-4">
            {/* Income Bracket */}
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-slate-50 text-slate-500 mt-0.5">
                <CreditCard className="w-4 h-4 text-emerald-600" />
              </div>
              <div>
                <span className="text-xs font-medium text-slate-400 block uppercase tracking-wider">Avg Income</span>
                <span className="text-sm font-semibold text-slate-700">{detail.avgIncome}</span>
              </div>
            </div>

            {/* Languages */}
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-slate-50 text-slate-500 mt-0.5">
                <Languages className="w-4 h-4 text-amber-500" />
              </div>
              <div>
                <span className="text-xs font-medium text-slate-400 block uppercase tracking-wider">Language Needs</span>
                <span className="text-sm font-semibold text-slate-700">{detail.languages}</span>
              </div>
            </div>

            {/* Digital Channels */}
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-slate-50 text-slate-500 mt-0.5">
                <Users className="w-4 h-4 text-indigo-500" />
              </div>
              <div>
                <span className="text-xs font-medium text-slate-400 block uppercase tracking-wider">Primary Channels</span>
                <span className="text-sm font-semibold text-slate-700">{detail.digitalChannels}</span>
              </div>
            </div>

            {/* Meters block */}
            <div className="pt-3 border-t border-slate-50 space-y-3">
              {/* Purchasing Power */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-slate-500">Purchasing Power Index</span>
                  <span className="text-slate-800 font-bold">{detail.purchasingPowerIndex}/100</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2">
                  <div
                    className="bg-emerald-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${detail.purchasingPowerIndex}%` }}
                  />
                </div>
              </div>

              {/* Digital Literacy */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-slate-500">Digital Literacy Index</span>
                  <span className="text-slate-800 font-bold">{detail.digitalLiteracy}/100</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2">
                  <div
                    className="bg-indigo-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${detail.digitalLiteracy}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Trust Vector */}
        <div className="mt-6 pt-4 border-t border-slate-100 bg-slate-50/50 -mx-6 -mb-6 p-6">
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Core Trust Drivers</span>
              <p className="text-xs text-slate-700 leading-relaxed font-medium">{detail.trustDrivers}</p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-gradient-to-r from-emerald-50 to-indigo-50/30 rounded-2xl p-5 border border-emerald-100/40 flex items-start gap-4">
        <div className="p-3 bg-white rounded-xl shadow-sm text-emerald-600 flex-shrink-0 hidden sm:block">
          <Compass className="w-6 h-6" />
        </div>
        <div>
          <h4 className="text-sm font-bold text-slate-800">Why Segmenting the masses matters</h4>
          <p className="text-xs text-slate-600 mt-1 leading-relaxed">
            The Indian consumer base is not a monolith. Tier-1 metros focus on product aesthetics and premium speed;
            meanwhile, Tier-2 and Tier-3 cities drive massive volume but require **vernacular outreach**, **low transactional friction (UPI/COD)**, and **local community validation**.
          </p>
        </div>
      </div>

      {/* Desktop view: Side by Side Matrix */}
      <div className="hidden lg:grid grid-cols-3 gap-6">
        {renderTierCard(
          "tier1",
          "Tier 1: Urban Metro",
          "Tech-Savvy Direct Shoppers",
          profile.tier1,
          "text-indigo-600",
          "bg-indigo-50"
        )}
        {renderTierCard(
          "tier2",
          "Tier 2: Growth Centers",
          "Aspirational Vernacular Buyers",
          profile.tier2,
          "text-emerald-700",
          "bg-emerald-50"
        )}
        {renderTierCard(
          "tier3",
          "Tier 3: The Indian Masses",
          "Value-Conscious Localists",
          profile.tier3,
          "text-amber-700",
          "bg-amber-50"
        )}
      </div>

      {/* Mobile view: Swipeable / Tabbed Matrix */}
      <div className="block lg:hidden">
        {/* Tabs switcher */}
        <div className="flex bg-slate-100 p-1 rounded-xl mb-4">
          <button
            onClick={() => setActiveMobileTab("tier1")}
            className={`flex-1 text-center py-2.5 text-xs font-semibold rounded-lg transition-all ${
              activeMobileTab === "tier1" ? "bg-white text-indigo-700 shadow-sm" : "text-slate-500"
            }`}
          >
            Tier 1 (Urban)
          </button>
          <button
            onClick={() => setActiveMobileTab("tier2")}
            className={`flex-1 text-center py-2.5 text-xs font-semibold rounded-lg transition-all ${
              activeMobileTab === "tier2" ? "bg-white text-emerald-700 shadow-sm" : "text-slate-500"
            }`}
          >
            Tier 2 (Growth)
          </button>
          <button
            onClick={() => setActiveMobileTab("tier3")}
            className={`flex-1 text-center py-2.5 text-xs font-semibold rounded-lg transition-all ${
              activeMobileTab === "tier3" ? "bg-white text-amber-700 shadow-sm" : "text-slate-500"
            }`}
          >
            Tier 3 (Masses)
          </button>
        </div>

        {/* Tab content */}
        <div className="min-h-[380px]">
          {activeMobileTab === "tier1" &&
            renderTierCard(
              "tier1",
              "Tier 1: Urban Metro",
              "Tech-Savvy Direct Shoppers",
              profile.tier1,
              "text-indigo-600",
              "bg-indigo-50"
            )}
          {activeMobileTab === "tier2" &&
            renderTierCard(
              "tier2",
              "Tier 2: Growth Centers",
              "Aspirational Vernacular Buyers",
              profile.tier2,
              "text-emerald-700",
              "bg-emerald-50"
            )}
          {activeMobileTab === "tier3" &&
            renderTierCard(
              "tier3",
              "Tier 3: The Indian Masses",
              "Value-Conscious Localists",
              profile.tier3,
              "text-amber-700",
              "bg-amber-50"
            )}
        </div>
      </div>

      {/* Core Takeaway block */}
      <div className="bg-slate-50/50 rounded-2xl p-5 border border-slate-100 text-center">
        <span className="text-xs font-bold text-slate-400 block uppercase tracking-widest mb-1">Structural Pivot Note</span>
        <p className="text-xs text-slate-700 max-w-2xl mx-auto leading-relaxed">
          {profile.tier3.volumePercent > 40 ? (
            <span className="font-semibold text-slate-800">
              💡 Volume Advantage: Tier 3 accounts for {profile.tier3.volumePercent}% of your addressable customer base. To win here, prioritize cash-on-delivery and localized customer onboarding over complex mobile apps.
            </span>
          ) : (
            <span className="font-semibold text-slate-800">
              💡 Strategy Insight: The mid-to-high ticket point suggests concentrating marketing spends on Tier 1 and Tier 2 regions, using high-trust regional creators and festive WhatsApp catalogs.
            </span>
          )}
        </p>
      </div>
    </div>
  );
}
