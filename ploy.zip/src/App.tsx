import React, { useState, useEffect } from "react";
import { GtmReport, CampaignPreset } from "./types";
import { CAMPAIGN_PRESETS, AVAILABLE_STATES, INDUSTRIES } from "./data";
import AudienceMatrix from "./components/AudienceMatrix";
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import GtmBlueprint from "./components/GtmBlueprint";
import PloyLogo from "./components/PloyLogo";

import {
  Compass,
  ArrowRight,
  TrendingUp,
  MapPin,
  CheckSquare,
  Users,
  Settings,
  AlertCircle,
  HelpCircle,
  FileText,
  Sliders,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  ChevronRight,
  ChevronLeft
} from "lucide-react";

export default function App() {
  // Linear workflow active tab state: "define" | "audience" | "analytics" | "blueprint"
  const [activeTab, setActiveTab] = useState<"define" | "audience" | "analytics" | "blueprint">("define");

  // Input states
  const [industry, setIndustry] = useState<string>(CAMPAIGN_PRESETS[0].industry);
  const [customIndustry, setCustomIndustry] = useState<string>("");
  const [isCustomIndustry, setIsCustomIndustry] = useState<boolean>(false);

  const [pricePoint, setPricePoint] = useState<number>(CAMPAIGN_PRESETS[0].pricePoint);
  const [goal, setGoal] = useState<string>(CAMPAIGN_PRESETS[0].goal);
  const [selectedState, setSelectedState] = useState<string>(CAMPAIGN_PRESETS[0].state);
  const [selectedTier, setSelectedTier] = useState<string>(CAMPAIGN_PRESETS[0].tier);

  // Active loaded report
  const [report, setReport] = useState<GtmReport | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load a preset on mount
  useEffect(() => {
    loadPreset(CAMPAIGN_PRESETS[0]);
  }, []);

  const loadPreset = (preset: CampaignPreset) => {
    setIsCustomIndustry(false);
    setIndustry(preset.industry);
    setPricePoint(preset.pricePoint);
    setGoal(preset.goal);
    setSelectedState(preset.state);
    setSelectedTier(preset.tier);
    setErrorMessage(null);
  };

  // Triggers API-based or local fallback GTM model generation
  const handleGenerateReport = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    setReport(null);

    const finalIndustry = isCustomIndustry ? customIndustry : industry;
    if (!finalIndustry.trim()) {
      setErrorMessage("Please select or enter an industry sector.");
      setIsLoading(false);
      return;
    }
    if (!goal.trim()) {
      setErrorMessage("Please enter a business scaling goal.");
      setIsLoading(false);
      return;
    }

    // Interactive animated loading phases for small ops teams
    const steps = [
      "Profiling micro-demographics for " + selectedState + "...",
      "Mapping local logistics networks & transport bottlenecks...",
      "Simulating channel customer acquisition costs (CAC)...",
      "Drafting high-converting vernacular marketing taglines...",
      "Finalizing mass-market distribution roadmaps..."
    ];

    let currentStepIdx = 0;
    setLoadingStep(steps[currentStepIdx]);
    const stepInterval = setInterval(() => {
      currentStepIdx++;
      if (currentStepIdx < steps.length) {
        setLoadingStep(steps[currentStepIdx]);
      }
    }, 1100);

    try {
      const response = await fetch("/api/gtm/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          industry: finalIndustry,
          pricePoint,
          goal,
          selectedState,
          selectedTier,
        }),
      });

      if (!response.ok) {
        throw new Error("Server responded with error: " + response.statusText);
      }

      const data = await response.json();
      setReport(data);
      // Advance to Step 2 (Audience comparative matrix)
      setActiveTab("audience");
    } catch (err: any) {
      console.error(err);
      setErrorMessage(
        "Could not generate localized insights. Please double-check connection and retry."
      );
    } finally {
      clearInterval(stepInterval);
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 text-slate-800 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* HEADER SECTION */}
      <header className="bg-white border-b border-slate-100 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          
          {/* Logo Brand with PLOY theme */}
          <div className="flex items-center gap-3">
            <PloyLogo height="44" width="135" className="hover:scale-105 transition-transform" />
            <div>
              <div className="flex items-center gap-2">
                <span className="px-1.5 py-0.5 text-[9px] font-bold text-emerald-800 bg-emerald-50 rounded border border-emerald-100/40 uppercase">
                  MSME Advisor
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Democratizing Localized Market Scaling</p>
            </div>
          </div>

          {/* Quick Info & User Context */}
          <div className="flex items-center gap-3 text-xs">
            <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-slate-500 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-ping" />
              <span>Live Regional Database Fresh</span>
            </div>
          </div>

        </div>
      </header>

      {/* SUB-HEADER PROGRESS STRIP */}
      {report && (
        <div className="bg-white border-b border-slate-100 py-2.5 shadow-xs">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <nav className="flex justify-between items-center overflow-x-auto gap-4 scrollbar-none py-1">
              
              {/* Step 1 */}
              <button
                onClick={() => setActiveTab("define")}
                className={`flex items-center gap-2 text-xs font-bold whitespace-nowrap px-3 py-1.5 rounded-lg transition-colors ${
                  activeTab === "define"
                    ? "bg-emerald-50 text-emerald-700 border border-emerald-100/40"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-mono">1</span>
                Campaign Scope
              </button>

              <ChevronRight className="w-4 h-4 text-slate-300 flex-shrink-0" />

              {/* Step 2 */}
              <button
                onClick={() => setActiveTab("audience")}
                className={`flex items-center gap-2 text-xs font-bold whitespace-nowrap px-3 py-1.5 rounded-lg transition-colors ${
                  activeTab === "audience"
                    ? "bg-emerald-50 text-emerald-700 border border-emerald-100/40"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-mono">2</span>
                Audience Matrix
              </button>

              <ChevronRight className="w-4 h-4 text-slate-300 flex-shrink-0" />

              {/* Step 3 */}
              <button
                onClick={() => setActiveTab("analytics")}
                className={`flex items-center gap-2 text-xs font-bold whitespace-nowrap px-3 py-1.5 rounded-lg transition-colors ${
                  activeTab === "analytics"
                    ? "bg-emerald-50 text-emerald-700 border border-emerald-100/40"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-mono">3</span>
                Market Analytics
              </button>

              <ChevronRight className="w-4 h-4 text-slate-300 flex-shrink-0" />

              {/* Step 4 */}
              <button
                onClick={() => setActiveTab("blueprint")}
                className={`flex items-center gap-2 text-xs font-bold whitespace-nowrap px-3 py-1.5 rounded-lg transition-colors ${
                  activeTab === "blueprint"
                    ? "bg-emerald-50 text-emerald-700 border border-emerald-100/40"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-mono">4</span>
                GTM Playbook
              </button>

            </nav>
          </div>
        </div>
      )}

      {/* MAIN CONTENT INNER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* FALLBACK BANNER INFORMATION */}
        {report?.isFallback && (
          <div className="bg-amber-50 border border-amber-200/50 rounded-2xl p-4 text-xs text-amber-800 flex items-start gap-3 mb-6">
            <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-bold">Notice:</span> {report.notice || "Currently rendering highly customized, state-specific playbook matrices curated from aggregated regional GTM metrics."}
            </div>
          </div>
        )}

        {/* LOADING SCREEN */}
        {isLoading && (
          <div className="min-h-[450px] flex flex-col items-center justify-center text-center py-12 px-4">
            <div className="relative mb-6">
              <div className="h-16 w-16 rounded-full border-4 border-slate-100 border-t-emerald-500 animate-spin" />
              <Compass className="w-6 h-6 text-emerald-500 absolute inset-0 m-auto animate-pulse" />
            </div>
            <h3 className="text-base font-bold text-slate-800">PLOY Advisory Engine Analyzing</h3>
            <p className="text-xs text-slate-500 max-w-xs mt-1 leading-relaxed font-mono font-medium text-emerald-600">
              {loadingStep}
            </p>
          </div>
        )}

        {/* MAIN VIEWS CONTAINER */}
        {!isLoading && (
          <div className="space-y-8">
            
            {/* VIEW A: CAMPAIGN DEFINITION SHEET */}
            {activeTab === "define" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* 1. Interactive Form Card */}
                <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-100 p-6 shadow-xs space-y-6">
                  <div>
                    <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                      <Settings className="w-5 h-5 text-emerald-600" />
                      Configure Scaling Parameters
                    </h3>
                    <p className="text-xs text-slate-500">
                      Specify your target Indian state, budget thresholds, and growth goals.
                    </p>
                  </div>

                  <form onSubmit={handleGenerateReport} className="space-y-5">
                    
                    {/* State Selector */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                          Target State
                        </label>
                        <select
                          value={selectedState}
                          onChange={(e) => setSelectedState(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-semibold focus:outline-none focus:border-emerald-500 transition-colors"
                        >
                          {AVAILABLE_STATES.map((st) => (
                            <option key={st} value={st}>
                              {st}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                          Target Consumer Tier
                        </label>
                        <select
                          value={selectedTier}
                          onChange={(e) => setSelectedTier(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-semibold focus:outline-none focus:border-emerald-500 transition-colors"
                        >
                          <option value="All Tiers">All Tiers (Complete Masses)</option>
                          <option value="Tier 2 & 3 Focus">Tier 2 & Tier 3 (Regional Towns/Rural)</option>
                          <option value="Tier 1 Metros">Tier 1 Metros (High Wealth Centres)</option>
                        </select>
                      </div>
                    </div>

                    {/* Industry Sector Dropdown or Custom Text */}
                    <div>
                      <div className="flex justify-between items-center mb-1.5">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                          Industry Sector
                        </label>
                        <button
                          type="button"
                          onClick={() => setIsCustomIndustry(!isCustomIndustry)}
                          className="text-[10px] font-bold text-emerald-700 hover:underline"
                        >
                          {isCustomIndustry ? "Use predefined sectors" : "Enter custom industry"}
                        </button>
                      </div>
                      {isCustomIndustry ? (
                        <input
                          type="text"
                          required
                          placeholder="e.g. Handmade Terracotta Pottery, Electric Two-Wheeler Accessories"
                          value={customIndustry}
                          onChange={(e) => setCustomIndustry(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-semibold focus:outline-none focus:border-emerald-500 transition-colors"
                        />
                      ) : (
                        <select
                          value={industry}
                          onChange={(e) => setIndustry(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-semibold focus:outline-none focus:border-emerald-500 transition-colors"
                        >
                          {INDUSTRIES.map((ind) => (
                            <option key={ind} value={ind}>
                              {ind}
                            </option>
                          ))}
                        </select>
                      )}
                    </div>

                    {/* Product Price Point Slider */}
                    <div>
                      <div className="flex justify-between items-center mb-1.5">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                          Avg. Product Price Point
                        </label>
                        <span className="text-sm font-bold text-emerald-700 font-mono">
                          ₹{pricePoint.toLocaleString("en-IN")}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="5000"
                        step="5"
                        value={pricePoint}
                        onChange={(e) => setPricePoint(Number(e.target.value))}
                        className="w-full accent-emerald-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                      />
                      <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                        <span>₹5 (Low Margin Snack)</span>
                        <span>₹1,000 (Lifestyle)</span>
                        <span>₹5,000 (Premium Tech)</span>
                      </div>
                    </div>

                    {/* Scale and Scaling Goal Description */}
                    <div>
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                        Scaling Campaign Goal
                      </label>
                      <textarea
                        required
                        rows={3}
                        placeholder="Define your concrete growth target. e.g. Achieve 10,000 orders across Western Maharashtra by establishing local kirana nodes."
                        value={goal}
                        onChange={(e) => setGoal(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-medium focus:outline-none focus:border-emerald-500 transition-colors resize-none leading-relaxed"
                      />
                    </div>

                    {/* Error Banner */}
                    {errorMessage && (
                      <div className="p-3 bg-rose-50 text-rose-800 text-xs font-medium rounded-xl border border-rose-100 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                        <span>{errorMessage}</span>
                      </div>
                    )}

                    {/* Run Report Button */}
                    <button
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-xl transition-all shadow-md shadow-emerald-600/10 flex items-center justify-center gap-2"
                    >
                      <span>Analyze Localized GTM Market</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                  </form>
                </div>

                {/* 2. Presets Quick-Launcher Cards */}
                <div className="lg:col-span-5 space-y-5">
                  <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-sm relative overflow-hidden flex flex-col justify-between">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
                    <div>
                      <span className="text-[10px] font-mono tracking-widest text-emerald-400 font-bold block mb-1">
                        MSME Accelerate
                      </span>
                      <h4 className="text-lg font-black tracking-tight">Need immediate direction?</h4>
                      <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                        Select one of our simulated MSME business blueprints to instantly experience the diagnostic capabilities of PLOY.
                      </p>

                      <div className="space-y-3.5 mt-6">
                        {CAMPAIGN_PRESETS.map((preset) => (
                          <div
                            key={preset.id}
                            onClick={() => {
                              loadPreset(preset);
                              // Smooth scroll to top of form if needed
                            }}
                            className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50 hover:bg-slate-800 hover:border-emerald-500/50 transition-all cursor-pointer flex flex-col justify-between"
                          >
                            <div className="flex justify-between items-start gap-2 mb-1.5">
                              <span className="font-bold text-xs text-slate-100">{preset.title}</span>
                              <span className="text-[9px] font-bold text-emerald-400 bg-emerald-900/40 border border-emerald-500/20 px-1.5 py-0.5 rounded uppercase flex-shrink-0">
                                {preset.badge}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                              {preset.description}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* VIEW B: AUDIENCE COMPARATIVE PERSONA BUILDER */}
            {activeTab === "audience" && report && (
              <div className="space-y-6">
                <div className="flex justify-between items-center flex-wrap gap-4">
                  <div>
                    <span className="text-xs font-bold text-emerald-600 block uppercase tracking-wider">Step 2 of 4</span>
                    <h2 className="text-xl font-black text-slate-900">Demographic Segment Profiler</h2>
                  </div>
                  <button
                    onClick={() => setActiveTab("analytics")}
                    className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-xs"
                  >
                    <span>Proceed to Market Analytics</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
                <AudienceMatrix profile={report.demographicProfile} />
              </div>
            )}

            {/* VIEW C: CORE DATA ANALYTICS & INSIGHTS */}
            {activeTab === "analytics" && report && (
              <div className="space-y-6">
                <div className="flex justify-between items-center flex-wrap gap-4">
                  <div>
                    <span className="text-xs font-bold text-emerald-600 block uppercase tracking-wider">Step 3 of 4</span>
                    <h2 className="text-xl font-black text-slate-900">Regional Insights & Heatmaps</h2>
                  </div>
                  <button
                    onClick={() => setActiveTab("blueprint")}
                    className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-xs"
                  >
                    <span>Proceed to Operational Blueprint</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
                <AnalyticsDashboard insights={report.marketInsights} stateName={selectedState} />
              </div>
            )}

            {/* VIEW D: DEPLOY AUTOMATED BLUEPRINT / EXPORT */}
            {activeTab === "blueprint" && report && (
              <div className="space-y-6">
                <div className="flex justify-between items-center flex-wrap gap-4">
                  <div>
                    <span className="text-xs font-bold text-emerald-600 block uppercase tracking-wider">Step 4 of 4</span>
                    <h2 className="text-xl font-black text-slate-900">Operational GTM Playbook</h2>
                  </div>
                  <button
                    onClick={() => {
                      setActiveTab("define");
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-4 py-2.5 rounded-xl transition-all"
                  >
                    <span>Adjust Campaign Parameters</span>
                  </button>
                </div>
                <GtmBlueprint blueprint={report.gtmBlueprint} />
              </div>
            )}

          </div>
        )}
      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-100 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-2">
          <p className="text-xs text-slate-400 font-medium">
            © 2026 PLOY Advisor. Tailored GTM playbooks specifically curated for lean startups and MSME teams.
          </p>
          <div className="flex justify-center gap-4 text-[10px] text-slate-400 font-mono">
            <span>Server Proxy: Online</span>
            <span>•</span>
            <span>Region Indexes Updated 7d ago</span>
            <span>•</span>
            <span>No Cookies Tracked</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
