import { CampaignPreset } from "./types";

export const CAMPAIGN_PRESETS: CampaignPreset[] = [
  {
    id: "maharashtra_snacks",
    title: "D2C Healthy Millet Snacks (Maharashtra)",
    industry: "FMCG / D2C Packaged Food",
    pricePoint: 40,
    goal: "Achieve 10,000 orders across Western Maharashtra by establishing rapid local distribution & vernacular social ads.",
    state: "Maharashtra",
    tier: "All Tiers",
    badge: "Agri-Food & D2C",
    description: "Targeting high-fiber, low-calorie millet puffs to health-conscious Tier-1 officegoers and quality-conscious Tier-2/3 mothers."
  },
  {
    id: "gujarat_apparel",
    title: "Festive Linen Apparel (Gujarat)",
    industry: "D2C Fashion & Apparel",
    pricePoint: 899,
    goal: "Sustain 1,500 monthly transactions in Saurashtra region during upcoming Navratri festivals via local influencer trust vectors.",
    state: "Gujarat",
    tier: "Tier 2 & 3 Focus",
    badge: "Lifestyle & Retail",
    description: "Sourcing premium linen with traditional weaves and marketing it with high-trust local language catalogs."
  },
  {
    id: "karnataka_fintech",
    title: "SME Micro-billing SaaS (Karnataka)",
    industry: "FinTech / SaaS",
    pricePoint: 499,
    goal: "Sign up 2,000 Kirana merchants in Hubli-Dharwad & Mysuru by offering offline-first voice ledger support.",
    state: "Karnataka",
    tier: "Tier 2 focus",
    badge: "B2B Software",
    description: "A super simplified bookkeeping software designed specifically for non-technical small merchants who handle transactions in Kannada."
  },
  {
    id: "tamilnadu_solar",
    title: "Low-cost Rooftop Solar (Tamil Nadu)",
    industry: "Cleantech & Hard-Goods",
    pricePoint: 45000,
    goal: "Acquire 100 rooftop solar installations in Tier 3 clusters of Salem & Trichy leveraging state subsidized finance plans.",
    state: "Tamil Nadu",
    tier: "Tier 3 & Semi-Urban",
    badge: "Infrastructure",
    description: "High-durability solar kits customized for domestic households suffering from peak-summer load shedding."
  }
];

export const AVAILABLE_STATES = [
  "Maharashtra",
  "Gujarat",
  "Karnataka",
  "Tamil Nadu",
  "Uttar Pradesh",
  "West Bengal",
  "Delhi",
  "Telangana",
  "Andhra Pradesh"
];

export const INDUSTRIES = [
  "FMCG / Packaged Food",
  "D2C Fashion & Lifestyle",
  "FinTech & Micro-finance",
  "AgriTech & Farm Services",
  "SaaS & B2B Software",
  "EduTech & Skill Training",
  "HealthTech & Local Clinics",
  "E-Commerce & Delivery",
  "Handicrafts & Artisanal Goods"
];
