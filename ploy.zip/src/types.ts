export interface DemographicDetail {
  avgIncome: string;
  digitalChannels: string;
  languages: string;
  purchasingPowerIndex: number; // 0-100
  digitalLiteracy: number; // 0-100
  trustDrivers: string;
  volumePercent: number; // e.g. 50 (for 50%)
}

export interface DemographicProfile {
  tier1: DemographicDetail;
  tier2: DemographicDetail;
  tier3: DemographicDetail;
}

export interface ChecklistItem {
  task: string;
  priority: "High" | "Medium" | "Low";
  desc: string;
  completed?: boolean;
}

export interface DistributionRoadmap {
  logisticsGuidelines: string;
  infrastructureChallenges: string;
  deliveryPartners: string;
  digitalOutreachChannels: string;
}

export interface GtmBlueprintType {
  localizationChecklist: ChecklistItem[];
  distributionRoadmap: DistributionRoadmap;
}

export interface HeatmapNode {
  name: string;
  pinCode: string;
  demandIntensity: number; // 0-100
  competitorDensity: number; // 0-100
  purchasingPowerIndex: number; // 0-100
}

export interface CacLtvPredictorNode {
  channel: string;
  cacMin: number;
  cacMax: number;
  ltvMin: number;
  ltvMax: number;
  efficiency: number; // 0-100
}

export interface SentimentNode {
  language: string;
  sentiment: "Positive" | "Negative" | "Neutral";
  sentimentScore: number; // 0-100
  sampleSlogan: string;
  translation: string;
}

export interface MarketInsights {
  regionalHeatmaps: HeatmapNode[];
  cacLtvPredictor: CacLtvPredictorNode[];
  vernacularSentiment: SentimentNode[];
}

export interface GtmReport {
  demographicProfile: DemographicProfile;
  gtmBlueprint: GtmBlueprintType;
  marketInsights: MarketInsights;
  isFallback?: boolean;
  notice?: string;
}

export interface CampaignPreset {
  id: string;
  title: string;
  industry: string;
  pricePoint: number;
  goal: string;
  state: string;
  tier: string;
  badge: string;
  description: string;
}
